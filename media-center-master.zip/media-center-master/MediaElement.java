import java.awt.BorderLayout;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.io.File;

import javax.swing.ImageIcon;
import javax.swing.JFrame;

import javafx.beans.binding.Bindings;
import javafx.embed.swing.JFXPanel;
import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.BorderPane;
import javafx.scene.media.Media;
import javafx.scene.media.MediaPlayer;

public class MediaElement {
	private JFrame mediaFrame = new JFrame();
	
	public MediaElement(File file) {
		System.out.println("Opening: " + file.getName() + ".");
	}
	
    void playMedia(File file) {
        JFXPanel fxPanel = new JFXPanel();
        mediaFrame.setSize(600, 400);
        mediaFrame.addWindowListener(new WindowAdapter() {
            public void windowClosing(WindowEvent event) {
            	System.out.println("Disposing media.");
                mediaFrame.dispose();
            }
        });
        mediaFrame.setIconImage(new ImageIcon("images/icon-red.png").getImage());
        mediaFrame.setVisible(true);
        mediaFrame.add(fxPanel, BorderLayout.CENTER);
        
    	Group root = new Group();
    	
    	if (!Utils.isImage(file.getName())) {
    		Media media = new Media(file.toURI().toString());
            MediaPlayer mediaPlayer = new MediaPlayer(media);
            mediaPlayer.setAutoPlay(true);
            Scene scene = new Scene(root);
            
            mediaFrame.setTitle(file.getName());
            
        	MediaControl mediaControl = new MediaControl(mediaPlayer, scene);
            scene.setRoot(mediaControl);
            
            fxPanel.setScene(scene);
    	} else {
    		Image image = new Image(file.toURI().toString());
    		ImageView imageView = new ImageView(image);
    		imageView.fitWidthProperty().bind(Bindings.selectDouble(imageView.sceneProperty(), "width"));
    		imageView.fitHeightProperty().bind(Bindings.selectDouble(imageView.sceneProperty(), "height"));
    		imageView.setPreserveRatio(true);
        	BorderPane imageBP = new BorderPane();
            Scene scene = new Scene(root);
            
        	imageBP.setCenter(imageView);
        	scene.setRoot(imageBP);
        	
            fxPanel.setScene(scene);
    	}
    }
}
