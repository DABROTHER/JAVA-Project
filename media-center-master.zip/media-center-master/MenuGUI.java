import java.awt.Color;
import java.awt.Cursor;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.SwingUtilities;

class MenuGUI implements ActionListener {
    JFrame guiFrame = new JFrame("Media Center");
    JPanel guiPanel = new JPanel(new GridBagLayout());
    JButton loadMediaButton = new JButton("Load Media");
    JFileChooser fc = new JFileChooser();

    public void invoke(MenuGUI menuGUI) {
        SwingUtilities.invokeLater(menuGUI::run);
    }

    public void run() {
        guiFrame.setSize(600, 400);
        guiFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        guiFrame.setIconImage(new ImageIcon("images/icon-blue.png").getImage());
        guiFrame.setVisible(true);
        guiPanel.setBackground(Color.WHITE);
        
        fc.addChoosableFileFilter(new MediaFilter());
        fc.setAcceptAllFileFilterUsed(false);
        fc.setCurrentDirectory(new java.io.File("."));
        fc.setDialogTitle("Select a media file");
        
        //Use grid bag constraint to position & pad elements
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.insets = new Insets(15, 15, 15, 15);

        addImages(gbc);
        gbc.gridy++;
        addButtons(gbc);
        
        guiFrame.add(guiPanel);
    }

    private void addButtons(GridBagConstraints gbc) {
    	loadMediaButton.setCursor(new Cursor(Cursor.HAND_CURSOR));
        loadMediaButton.addActionListener(this);
        guiPanel.add(loadMediaButton, gbc);
    }
    
    private void addImages(GridBagConstraints gbc) {
    	ImageIcon image = new ImageIcon("images/icon-blue.png");
        JLabel icon = new JLabel(image); 
        
        guiPanel.add(icon);
    }

    public void actionPerformed(ActionEvent event) {
        if (event.getSource() == loadMediaButton) {
            openFileSelector();
        }
    }

    private void openFileSelector() {
        int returnVal = fc.showOpenDialog(loadMediaButton);

        if (returnVal == JFileChooser.APPROVE_OPTION) {
        	File file = fc.getSelectedFile();
        	MediaElement media = new MediaElement(file);
        	media.playMedia(file);
        } else {
            System.out.println("File selector closed by user.");
        }
    }
}
