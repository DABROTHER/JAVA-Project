import javax.swing.UIManager;

public class MediaCenter {
    public static void main(String[] args) {
    	try {
            //Improve look of things like file pickers
            UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
        } catch(Exception okthen) {
        }
    	
        MenuGUI menuGUI = new MenuGUI();
        menuGUI.invoke(menuGUI);
    }
}