import java.io.File;

import javax.swing.filechooser.FileFilter;

//Based on: http://docs.oracle.com/javase/tutorial/uiswing/components/filechooser.html#filters
public class MediaFilter extends FileFilter {
	@Override
	public boolean accept(File f) {
		if (f.isDirectory()) {
	        return true;
	    }

	    String extension = Utils.getExtension(f);
	    if (extension != null) {
	        if (extension.equals(Utils.tiff) ||
	            extension.equals(Utils.tif) ||
	            extension.equals(Utils.gif) ||
	            extension.equals(Utils.jpeg) ||
	            extension.equals(Utils.jpg) ||
	            extension.equals(Utils.png) ||
	            
	            extension.equals(Utils.mp3) ||
	            
	            extension.equals(Utils.mp4) ||
	            extension.equals(Utils.wav)) {
	                return true;
	        } else {
	            return false;
	        }
	    }

	    return false;
	}

	@Override
	public String getDescription() {
		// TODO Auto-generated method stub
		return null;
	}

}
