import javafx.application.Platform;
import javafx.beans.InvalidationListener;
import javafx.beans.Observable;
import javafx.beans.binding.Bindings;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.layout.Priority;
import javafx.scene.layout.Region;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Cursor;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.Slider;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Pane;
import javafx.scene.media.MediaPlayer;
import javafx.scene.media.MediaPlayer.Status;
import javafx.scene.media.MediaView;
import javafx.scene.paint.Color;
import javafx.util.Duration;

//Based on: https://docs.oracle.com/javafx/2/media/playercontrol.htm
public class MediaControl extends BorderPane {
    private MediaPlayer mp;
    private MediaView mediaView;
    private boolean repeat = false;
    private boolean stopRequested = false;
    private boolean atEndOfMedia = false;
    private Duration duration;
    private Slider timeSlider;
    private Label playTime;
    private Slider volumeSlider;
    private HBox mediaBar;
    
    //Useful resources
    Image playIcon = new Image(getClass().getResourceAsStream("images/play.png"));
    Image pauseIcon = new Image(getClass().getResourceAsStream("images/pause.png"));
    Image repeatIcon = new Image(getClass().getResourceAsStream("images/repeat.png"));
    Image repeatActiveIcon = new Image(getClass().getResourceAsStream("images/repeat-active.png"));

    public MediaControl(final MediaPlayer mp, Scene scene) {
    	this.mp = mp;
    	setStyle("-fx-background-color: #fff;");
        mediaView = new MediaView(mp);
        Pane mediaPane = new Pane(mediaView);
        setCenter(mediaPane);
        
        duration = mp.getMedia().getDuration();
        
        mediaView.fitWidthProperty().bind(Bindings.selectDouble(mediaView.sceneProperty(), "width"));
        mediaView.fitHeightProperty().bind(Bindings.selectDouble(mediaView.sceneProperty(), "height"));
        
        mediaBar = new HBox();
        mediaBar.setAlignment(Pos.CENTER);
        mediaBar.setStyle("-fx-background-color: rgba(0, 0, 0, 0.3);");
        mediaBar.setPadding(new Insets(5, 10, 5, 10));
        BorderPane.setAlignment(mediaBar, Pos.CENTER);
        
        Button playButton = new Button("", new ImageView(pauseIcon));
        playButton.setStyle("-fx-background-color: transparent;");
        playButton.setOpacity(0.7);
        playButton.addEventHandler(MouseEvent.MOUSE_ENTERED, 
    	    new EventHandler<MouseEvent>() {
    	        @Override public void handle(MouseEvent e) {
    	        	playButton.setOpacity(1);
    	        	scene.setCursor(Cursor.HAND);
    	        }
    		}
        );
        playButton.addEventHandler(MouseEvent.MOUSE_EXITED, 
    	    new EventHandler<MouseEvent>() {
    	        @Override public void handle(MouseEvent e) {
    	        	playButton.setOpacity(0.7);
    	        	scene.setCursor(Cursor.DEFAULT);
    	        }
    		}
        );
        playButton.setOnAction(new EventHandler<ActionEvent>() {
            public void handle(ActionEvent e) {
                Status status = mp.getStatus();

                if (status == Status.UNKNOWN || status == Status.HALTED) {
                    //Don't do anything in these states
                    return;
                }

                if (status == Status.PAUSED || status == Status.READY || status == Status.STOPPED) {
                    //Rewind the movie if we're sitting at the end
                    if (atEndOfMedia) {
                        mp.seek(mp.getStartTime());
                        atEndOfMedia = false;
                    }
                    mp.play();
                } else {
                    mp.pause();
                }
            }
        });
        mp.currentTimeProperty().addListener(new InvalidationListener() {
            public void invalidated(Observable ov) {
                updateValues();
            }
        });

        mp.setOnPlaying(new Runnable() {
            public void run() {
                if (stopRequested) {
                    mp.pause();
                    stopRequested = false;
                } else {
                    playButton.setGraphic(new ImageView(pauseIcon));
                }
            }
        });

        mp.setOnPaused(new Runnable() {
            public void run() {
                playButton.setGraphic(new ImageView(playIcon));
            }
        });
        
        mp.setCycleCount(repeat ? MediaPlayer.INDEFINITE : 1);
        mp.setOnEndOfMedia(new Runnable() {
            public void run() {
            	System.out.println("End of media, repeat: " + repeat);
                if (repeat) {
                	mp.seek(mp.getStartTime());
                } else {
                    playButton.setGraphic(new ImageView(playIcon));
                    stopRequested = true;
                    atEndOfMedia = true;
                }
            }
        });
        mediaBar.getChildren().add(playButton);
        
        //Repeat
        Button repeatButton = new Button("", new ImageView(repeatIcon));
        repeatButton.setStyle("-fx-background-color: transparent;");
        repeatButton.setOpacity(0.7);
        repeatButton.addEventHandler(MouseEvent.MOUSE_ENTERED, 
    	    new EventHandler<MouseEvent>() {
    	        @Override public void handle(MouseEvent e) {
    	        	repeatButton.setOpacity(1);
    	        	scene.setCursor(Cursor.HAND);
    	        }
    		}
        );
        repeatButton.addEventHandler(MouseEvent.MOUSE_EXITED, 
    	    new EventHandler<MouseEvent>() {
    	        @Override public void handle(MouseEvent e) {
    	        	repeatButton.setOpacity(0.7);
    	        	scene.setCursor(Cursor.DEFAULT);
    	        }
    		}
        );
        repeatButton.setOnAction(new EventHandler<ActionEvent>() {
            public void handle(ActionEvent e) {
                if (repeat) {
                    repeat = false;
                    repeatButton.setGraphic(new ImageView(repeatIcon));
                } else {
                    repeat = true;
                    repeatButton.setGraphic(new ImageView(repeatActiveIcon));
                }
            }
        });
        mediaBar.getChildren().add(repeatButton);
        
        //Spacer
        Label spacer = new Label("   ");
        mediaBar.getChildren().add(spacer);

        //Time label
        Label timeLabel = new Label("Time ");
        timeLabel.setTextFill(Color.WHITE);
        mediaBar.getChildren().add(timeLabel);

        //Time slider
        timeSlider = new Slider();
        HBox.setHgrow(timeSlider, Priority.ALWAYS);
        timeSlider.setMaxWidth(Double.MAX_VALUE);
        timeSlider.valueProperty().addListener(new InvalidationListener() {
            public void invalidated(Observable ov) {
                if (timeSlider.isValueChanging()) {
                    // multiply duration by percentage calculated by slider position
                    mp.seek(duration.multiply(timeSlider.getValue() / 100.0));
                }
            }
        });
        mediaBar.getChildren().add(timeSlider);
        
        //Current time in video
        playTime = new Label();
        playTime.setPrefWidth(130);
        playTime.setMinWidth(50);
        playTime.setTextFill(Color.WHITE);
        mediaBar.getChildren().add(playTime);

        //Volume label
        Label volumeLabel = new Label("Vol ");
        volumeLabel.setTextFill(Color.WHITE);
        mediaBar.getChildren().add(volumeLabel);

        //Volume slider
        volumeSlider = new Slider();
        volumeSlider.setPrefWidth(70);
        volumeSlider.setMaxWidth(Region.USE_PREF_SIZE);
        volumeSlider.valueProperty().addListener(new InvalidationListener() {
            public void invalidated(Observable ov) {
                if (volumeSlider.isValueChanging()) {
                    mp.setVolume(volumeSlider.getValue() / 100.0);
                }
            }
        });
        mediaBar.getChildren().add(volumeSlider);
        
        setBottom(mediaBar);
    }

    protected void updateValues() {
        if (playTime != null && timeSlider != null && volumeSlider != null) {
            Platform.runLater(new Runnable() {
                public void run() {
                	if (duration.isUnknown()) {
                    	duration = mp.getMedia().getDuration();
                    }
                    
                    Duration currentTime = mp.getCurrentTime();
                    playTime.setText(formatTime(currentTime, duration));
                    
                    timeSlider.setDisable(duration.isUnknown());
                    if (!timeSlider.isDisabled() && duration.greaterThan(Duration.ZERO) && !timeSlider.isValueChanging()) {
                        timeSlider.setValue(currentTime.divide(Double.parseDouble(duration.toString().replace(" ms", ""))).toMillis()*100.0);
                    }
                    if (!volumeSlider.isValueChanging()) {
                        volumeSlider.setValue((int) Math.round(mp.getVolume()*100));
                    }
                }
            });
        }
    }

    private static String formatTime(Duration elapsed, Duration duration) {
        int intElapsed = (int) Math.floor(elapsed.toSeconds());
        int elapsedHours = intElapsed / (60 * 60);
        if (elapsedHours > 0) {
            intElapsed -= elapsedHours * 60 * 60;
        }
        int elapsedMinutes = intElapsed / 60;
        int elapsedSeconds = intElapsed - elapsedHours * 60 * 60
                - elapsedMinutes * 60;

        if (duration.greaterThan(Duration.ZERO)) {
            int intDuration = (int) Math.floor(duration.toSeconds());
            int durationHours = intDuration / (60 * 60);
            if (durationHours > 0) {
                intDuration -= durationHours * 60 * 60;
            }
            int durationMinutes = intDuration / 60;
            int durationSeconds = intDuration - durationHours * 60 * 60
                    - durationMinutes * 60;
            if (durationHours > 0) {
                return String.format("%d:%02d:%02d/%d:%02d:%02d",
                        elapsedHours, elapsedMinutes, elapsedSeconds,
                        durationHours, durationMinutes, durationSeconds);
            } else {
                return String.format("%02d:%02d/%02d:%02d",
                        elapsedMinutes, elapsedSeconds, durationMinutes,
                        durationSeconds);
            }
        } else {
            if (elapsedHours > 0) {
                return String.format("%d:%02d:%02d", elapsedHours,
                        elapsedMinutes, elapsedSeconds);
            } else {
                return String.format("%02d:%02d", elapsedMinutes,
                        elapsedSeconds);
            }
        }
    }
}